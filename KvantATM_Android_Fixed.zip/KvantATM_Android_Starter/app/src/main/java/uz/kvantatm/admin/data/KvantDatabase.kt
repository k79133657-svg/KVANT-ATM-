package uz.kvantatm.admin.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Student::class], version = 1, exportSchema = false)
abstract class KvantDatabase : RoomDatabase() {
    abstract fun studentDao(): StudentDao

    companion object {
        @Volatile private var INSTANCE: KvantDatabase? = null

        fun get(context: Context): KvantDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    KvantDatabase::class.java,
                    "kvant_atm.db"
                ).build().also { INSTANCE = it }
            }
    }
}
