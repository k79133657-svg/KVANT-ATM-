package uz.kvantatm.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import uz.kvantatm.admin.data.KvantDatabase
import uz.kvantatm.admin.data.Student
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val KvantYellow = Color(0xFFFFC928)
private val Ink = Color(0xFF171717)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = KvantDatabase.get(this).studentDao()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Ink, secondary = KvantYellow, background = Color(0xFFF7F7F7)
            )) {
                AdminHome(AdminViewModel(dao))
            }
        }
    }
}

class AdminViewModel(private val dao: uz.kvantatm.admin.data.StudentDao) : ViewModel() {
    val students = dao.observeStudents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun addStudent(name: String, phone: String, group: String, fee: Long) {
        if (name.isBlank()) return
        viewModelScope.launch {
            dao.insert(Student(fullName = name.trim(), phone = phone.trim(),
                groupName = group.trim(), monthlyFee = fee))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHome(vm: AdminViewModel) {
    val students by vm.students.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("KVANT ATM", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Text("Administrator paneli", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                actions = {
                    IconButton(onClick = { showAdd = true }) {
                        Icon(Icons.Default.Add, contentDescription = "O‘quvchi qo‘shish")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = KvantYellow) {
                Icon(Icons.Default.Add, contentDescription = "Qo‘shish", tint = Ink)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(Color(0xFFF7F7F7)).padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("O‘quvchilar", students.size.toString(), Modifier.weight(1f))
                    StatCard("Guruhlar", students.map { it.groupName }.filter { it.isNotBlank() }.distinct().size.toString(), Modifier.weight(1f))
                }
            }
            item {
                Text("O‘quvchilar", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            if (students.isEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.People, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("Hozircha o‘quvchilar yo‘q", fontWeight = FontWeight.SemiBold)
                            Text("Yangi o‘quvchi qo‘shish uchun + tugmasini bosing.", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                }
            }
            items(students, key = { it.id }) { student ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(student.fullName, fontWeight = FontWeight.Bold)
                        Text(listOf(student.phone, student.groupName).filter { it.isNotBlank() }.joinToString(" • "), color = Color.Gray, fontSize = 13.sp)
                        Text("${student.monthlyFee} so‘m / oy", color = Ink, fontSize = 13.sp)
                    }
                }
            }
        }
    }

    if (showAdd) AddStudentDialog(
        onDismiss = { showAdd = false },
        onSave = { n, p, g, f -> vm.addStudent(n, p, g, f); showAdd = false }
    )
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = KvantYellow, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AddStudentDialog(onDismiss: () -> Unit, onSave: (String, String, String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("") }
    var fee by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yangi o‘quvchi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("F.I.Sh. *") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Telefon") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(group, { group = it }, label = { Text("Guruh") }, singleLine = true)
                OutlinedTextField(fee, { fee = it }, label = { Text("Oylik to‘lov (so‘m)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name, phone, group, fee.toLongOrNull() ?: 0L) }, enabled = name.isNotBlank()) {
                Text("Saqlash")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}
