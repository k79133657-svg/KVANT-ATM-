package uz.kvantatm.admin.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM students WHERE isActive = 1 ORDER BY fullName")
    fun observeStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE fullName LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' ORDER BY fullName")
    fun searchStudents(query: String): Flow<List<Student>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(student: Student)

    @Query("UPDATE students SET isActive = 0, updatedAt = :now, syncPending = 1 WHERE id = :id")
    suspend fun archive(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM students WHERE syncPending = 1")
    suspend fun pendingSync(): List<Student>
}
