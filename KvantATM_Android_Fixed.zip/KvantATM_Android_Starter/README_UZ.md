# KVANT ATM — Android Admin Starter

Bu loyiha Kvant ATM o‘quv markazi uchun Android administrator ilovasining boshlang‘ich manba kodi.

## Hozirgi holati
- Kotlin + Jetpack Compose interfeysi
- Room lokal ma’lumotlar bazasi
- O‘quvchi qo‘shish va ro‘yxatini ko‘rish
- Guruhlar sonini o‘quvchi yozuvlaridan hisoblash
- Offline ishlash uchun lokal saqlash

## Ishga tushirish
1. Android Studio'ni o‘rnating.
2. ZIP faylni oching.
3. Android Studio orqali `KvantATM` papkasini oching.
4. Gradle sync tugashini kuting.
5. Android SDK 35 va JDK 17 mavjudligini tekshiring.
6. Emulator yoki Android telefonni ulang va Run tugmasini bosing.

## Hybrid sinxronlash bo‘yicha keyingi ish
Bu starterda Firebase hali ulanmagan. Real online sinxronlashni yoqish uchun:
1. Firebase Console'da yangi Android loyiha yarating.
2. Ilova ID: `uz.kvantatm.admin`
3. `google-services.json` faylini `app/` ichiga joylashtiring.
4. Firebase Authentication va Cloud Firestore'ni sozlang.
5. Server tomonida foydalanuvchi rollari va Firestore Security Rules'ni belgilang.
6. WorkManager orqali `syncPending` yozuvlarini xavfsiz sinxronlashni qo‘shing.

## Muhim
Bu ishlab chiqish uchun boshlang‘ich versiya, hali tayyor ishlab chiqarish ilovasi yoki o‘rnatishga tayyor APK emas. Firebase autentifikatsiyasi, to‘lovlar, davomat, testlar, rollar, zaxira nusxa, konfliktlarni hal qilish va xavfsizlik sinovlari keyingi bosqichlarda qo‘shiladi. Haqiqiy o‘quvchi ma’lumotlarini sinovdan o‘tmagan versiyaga kiritmang.


## Tuzatish (0.1.1)
Java va Kotlin/KSP kompilyatsiya maqsadi Java 17 ga bir xil qilindi.
Bu versiya hali boshlang‘ich loyiha: Firebase sinxronlash, autentifikatsiya,
to‘lovlar va davomat keyingi bosqichlarda qo‘shiladi.
